package com.example.issueproject.dto

data class SingUpInfo(
    val id: String,
    val pw: String,
    val name: String,
    val job: String
)
