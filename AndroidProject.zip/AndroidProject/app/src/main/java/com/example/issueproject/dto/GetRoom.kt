package com.example.issueproject.dto

data class GetRoom(
    val room: String
)
