package com.example.issueproject.dto

data class AddManagement(
    val title: String,
    val content: String,
    val date: String,
    val school: String,
    val room: String,
    val menu: String
)
