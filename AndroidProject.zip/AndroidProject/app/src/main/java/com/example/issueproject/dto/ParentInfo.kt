package com.example.issueproject.dto

data class ParentInfo(
    val id: String,
    val school: String,
    val room: String,
    val number: String,
    val name: String,
    val age: String,
    val spec: String
)
