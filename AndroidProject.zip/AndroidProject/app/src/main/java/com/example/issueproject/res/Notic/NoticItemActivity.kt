package com.example.issueproject.res.Notic

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.issueproject.R

class NoticItemActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notic_item)
    }
}