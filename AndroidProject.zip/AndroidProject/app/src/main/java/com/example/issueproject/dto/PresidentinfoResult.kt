package com.example.issueproject.dto

data class PresidentinfoResult(
    val id: String,
    val school: String,
    val room: String,
    val presi_num: String,
    val presi_image: String
)
