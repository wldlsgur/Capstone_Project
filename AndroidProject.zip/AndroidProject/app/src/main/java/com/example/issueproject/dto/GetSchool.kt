package com.example.issueproject.dto

data class GetSchool(
    val school: String
)
