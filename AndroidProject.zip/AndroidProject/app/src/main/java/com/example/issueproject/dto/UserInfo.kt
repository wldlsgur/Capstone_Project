package com.example.issueproject.dto

data class UserInfo(
    val name: String,
    val job: String
)
