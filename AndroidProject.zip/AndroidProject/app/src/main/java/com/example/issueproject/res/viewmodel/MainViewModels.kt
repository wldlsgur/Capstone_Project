package com.example.issueproject.res.viewmodel

import androidx.lifecycle.ViewModel

class MainViewModels : ViewModel() {
    var userId:String = ""
}