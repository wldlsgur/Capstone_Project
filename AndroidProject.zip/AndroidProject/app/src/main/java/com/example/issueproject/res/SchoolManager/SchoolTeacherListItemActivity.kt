package com.example.issueproject.res.SchoolManager

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.issueproject.R

class SchoolTeacherListItemActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_school_teacher_list_item)
    }
}