package com.example.issueproject.dto

data class Presidentinfo(
    val id: String,
    val school: String,
    val room: String,
    val number: String
)
