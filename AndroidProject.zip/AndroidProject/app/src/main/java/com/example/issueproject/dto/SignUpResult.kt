package com.example.issueproject.dto

data class SignUpResult(
    val res : Boolean,
    val msg : String
)
