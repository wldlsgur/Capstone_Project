package com.example.issueproject.dto

data class AddManagementResult(
    val res : Boolean,
    val msg : String
)
