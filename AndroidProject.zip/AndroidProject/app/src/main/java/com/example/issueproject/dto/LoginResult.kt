package com.example.issueproject.dto

data class LoginResult(
    val res : Boolean,
    val msg : String
)