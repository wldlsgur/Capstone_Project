package com.example.issueproject.dto

data class DayNoticInfo(
    val date : String,
    val title : String
)
