package com.example.issueproject.res.RoomManager

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.issueproject.R

class RoomChildListItemActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_room_child_list_item)
    }
}