package com.example.issueproject.dto

class ParentInfoResult (
    val id: String,
    val school: String,
    val room: String,
    val number: String,
    val name: String,
    val age: String,
    val image: String,
    val spec: String,
    val checked: Boolean
)